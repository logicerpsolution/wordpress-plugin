<?php

include('../../../wp-config.php');
global $wpdb;

   if(isset($_REQUEST['del_id'])){
      $wpdb->query("delete from wp_yoga_style where ID=".$_REQUEST['del_id']);
      wp_redirect(admin_url().'/admin.php?page=listyoga-style');
 } 
 
 ?>