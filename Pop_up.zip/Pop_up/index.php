<?php
/**
* Plugin Name: Pop up
* Plugin URI: http://mypluginuri.com/
* Description: A brief description about your plugin.
* Version: 1.0 or whatever version of the plugin (pretty self explanatory)
* Author: jasdeep
* Author URI: Author's website
* License: A "Slug" license name e.g. GPL12
*/
session_start();
require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
//include('wp-config.php');
 
function pop_up_actions() {
    //add_options_page("Yoga style", "Yoga style", 1, "Yoga style", "my_function");
	 add_menu_page( "Pop up", "Popup", 1, "pop-up", "popup_function" ); 
}
 
add_action('admin_menu', 'pop_up_actions');
function popup_function(){
global $wpdb,$post;
if(current_user_can( 'administrator' )){
} else{
								if(is_user_logged_in()){
								$loginuser_id=get_current_user_id();
								}
								$type=get_user_meta($loginuser_id,'wp_capabilities');
								if($type[0]['School']==1){
									$s=1;
								}else{
									//echo "No";
									$t=1;
								}
										$args=("SELECT * FROM `wp_posts` WHERE `post_author`=".$loginuser_id." and `post_type`='product' order by day(`post_date`)");
										$my_query=$wpdb->get_results($args);
										?>		
                                            <td class="btd"> 
											  <table width="100%">
											   	<?php 
												foreach($my_query as $post){  
													 $id=$post->ID;
													 //echo 'ID='.$id;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
												if($day == 'Mon'){ ?>
												<tr>
												<td style="padding:5px">
												<div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">1</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-mon<?php echo $id; ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
											<div class="modal fade" id="class-mon<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required/>
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														 <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                    
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                          
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                      
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											<?php //} ?>
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php } } ?>
												</table>
                                              </td>  
											  <td class="btd">
											  <table width="100%">
											  <?php 
												foreach($my_query as $post){   
													 //$my_query->the_post();
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											    if($day == 'Tue'){ ?>
												<tr>
												<td style="padding:5px">
                                                <div>
												
													<p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">5</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-tue<?php echo $id; ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
												
												<div class="modal fade" id="class-tue<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
												?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required/>
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														  <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                    
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                         
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php } } ?>
												</table>
                                              </td>  
                                              <td class="btd">
											  <table width="100%">
											  <?php 
												 foreach($my_query as $post){   
													 //$my_query->the_post();
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											  if($day == 'Wed'){?>
												
											   <tr>
												<td style="padding:5px">
                                                <div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">0</p>
                                                    <p class="frt editicon">
                                                       <a href="#class-wed<?php echo $id; ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
												
												<div class="modal fade" id="class-wed<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required />
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														  <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                    
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                        
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                           <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                           
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php 
												
												} } ?>
												</table>
                                              </td>  
											 <td class="btd">
											  <table width="100%">
											  <?php 
												foreach($my_query as $post){  
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											  if($day == 'Thu'){ ?>
											  <tr>
												<td style="padding:5px">
                                                <div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">2</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-thu<?php echo $id;?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
												
												<div class="modal fade" id="class-thu<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required />
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														  <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                   
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                          
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                        
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>" />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                           <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php } } ?>
												</table>
                                              </td>  
                                              <td class="btd">
											  <table width="100%">
											  <?php 
												foreach($my_query as $post){  
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											  if($day == 'Fri'){?>
											  <tr>
												<td style="padding:5px">
                                                <div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">1</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-fri<?php echo $id; ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
												
												<div class="modal fade" id="class-fri<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required />
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														 <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                   
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                         
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                       
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price));{ echo $price[0]; } ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                           
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php } } ?>
												</table>
                                              </td>  
                                              <td class="btd">
											  <table width="100%">
											  <?php 
												foreach($my_query as $post){  
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											  if($day == 'Sat'){?>
											  <tr>
												<td style="padding:5px">
												<div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">0</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-sat<?php echo $id;?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div> 
												</td>
												</tr>
												
												<div class="modal fade" id="class-sat<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required />
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                           <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														  <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                   
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                          
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                        
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
												<?php } } ?>
												</table>
                                              </td>  
                                              <td class="btd">
											  <table width="100%">
											  <?php 
												foreach($my_query as $post){  
													 $id=$post->ID;
													 $day=get_the_date('D');
													 $stme=get_post_meta($id,'s_time');
													 $etme=get_post_meta($id,'e_time');
													 $tn=get_post_meta($id,'teacher_name');
													 $ys=get_post_meta($id,'yoga_style');
													 $price=get_post_meta($id,'_price');
													 $stock=get_post_meta($id,'_stock_status');
											  if($day == 'Sun'){ ?>
											  <tr>
												<td style="padding:5px">
                                                <div>
												    <p><?php echo $ys[0];?></p>
                                                    <p><?php echo $stme[0]; ?> TO <?php echo $etme[0]; ?></p>
                                                    <p><?php echo ucfirst($tn[0]); ?></p>
                                                    <p class="editicon">0</p>
                                                    <p class="frt editicon">
                                                        <a href="#class-sun<?php echo $id; ?>" data-toggle="modal" data-dismiss="modal"><i class="fa fa-pencil-square-o"></i></a>
                                                        <a href="javascript:del(<?php echo $id; ?>)"><i class="fa fa-trash-o"></i></a>
                                                    </p>
												</div>
												</td>
												</tr>
												
												<div class="modal fade" id="class-sun<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                                    <div class="modal-dialog mt150">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
												   
                                                    <h3 class="modal-title text-center header-modal">Edit Class</h3>
                                            </div>
											<?php
												$stm=explode(' ',$stme[0]);
												$etm=explode(' ',$etme[0]);
												$name=get_post($id);
												$date=get_the_date('Y-m-d');
												$t_id=get_post_meta($id,'teacher_id');
											?>
                                             <div class="modal-body body-padding pt0">
											<form name="form1" method="post" action="">
                                                <div class="form-horizontal">
                                                     <div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Class name:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="cname" class="form-control" value="<?php echo $name->post_title; ?>" id="txtclassname" placeholder="Class name" required />
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtclassdate" class="col-sm-3 control-label">Date:</label>
                                                        <div class="col-sm-9">
														
														<input class="datepicker form-control" data-date-format="yyyy-mm-dd" value="<?php echo $date; ?>" id="user_dob" name="date" placeholder="yyyy-mm-dd" readonly="readonly" 
                                                            type="text" />
                                                        </div>
                                                    </div>
													
                                                    <div class="form-group fs14">
                                                        <label for="txttime" class="col-sm-3 control-label">Time:</label>
														<div class="col-sm-4" style="height:35px;">
														
                                                      <input type="text" name="stime" value="<?php echo $stm[0]; ?>" class="form-control" id="txttimeto" placeholder="--:--" required />
													      <select name="st" class="selecttime form-control">
															  <option value="AM" <?php if($stm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($stm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
														</div>
														
                                                        <div class="col-sm-4" style="height:35px;">
                                                          <input type="text" name="etime" value="<?php echo $etm[0]; ?>" class="form-control" id="txttimefrom" placeholder="--:--" required />
														  <select name="et" class="selecttime form-control">
															  <option value="AM" <?php if($etm[1]=='AM'){ ?> selected <?php } ?>>AM</option>
															  <option value="PM"<?php if($etm[1]=='PM'){  ?> selected <?php } ?>>PM</option>
														  </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
													<?php if($s==1){ ?>
													<label for="txtteacher" class="col-sm-3 control-label">Teacher:</label>
                                                        <div class="col-sm-9">
                                                          <input type="hidden" name="sid" value="school"/>
														  <select name="teacher" class="form-control pdd" id="txtteacher">
														  <?php if(isset($tn)){ ?> <option value="<?php echo $tn[0].','.$t_id[0]; ?>"><?php echo ucfirst($tn[0]); ?></option> <?php } else { ?>
                                                          <option>----------Select Teacher----------</option>
														 <?php }
														    $record=get_userdata($loginuser_id);
															 $tid=$record->teacher_ids;
                                                            	foreach($tid as $ids){	
																$teach=get_userdata($ids); 
														?>
														<option value="<?php echo $teach->user_login.','.$ids; ?>"><?php  echo  ucfirst($teach->user_login); ?></option>
														<?php }   ?>
														</select>
														</div>
														<?php } ?>
                                                    </div>
                                                   
													<div class="form-group fs14">
													
													<label for="txtyogastyle" class="col-sm-3 control-label">Yoga Style:</label>
													<div class="col-sm-9">
                                                         
														<select name="yoga_style" class="form-control pdd" id="yoga_style">
														<?php if(isset($ys)){ ?> <option><?php echo $ys[0]; ?></option> <?php } else { ?>
                                                          <option>---------Select Yoga Style--------<option>
														 <?php } 
																	$sql= $wpdb->get_col("select yoga_style_name from wp_yoga_style");
															 		foreach($sql as $yogastyle){
																?>
															<option value="<?php echo $yogastyle; ?>">
																<?php echo $yogastyle; ?>
															</option>
															<?php } ?>
														</select>
														</div>
                                                        
                                                    </div>
													<div class="form-group fs14">
                                                        <label for="txtclassname" class="col-sm-3 control-label">Price:</label>
                                                        <div class="col-sm-9">
                                                          <input type="text" name="price" class="form-control" id="txtprice" placeholder="Enter class price" required value="<?php if(isset($price)){ echo $price[0]; } ?>"/>
                                                        </div>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <label for="txtteacher" class="col-sm-4 col-sm-offset- control-label">Full:<input type="checkbox" name="full" value="full" class="ml30" <?php if($stock[0]=="outofstock"){ ?> checked="checked" <?php } ?> /></label>
                                                    </div>
                                                    <div class="form-group fs14">
                                                        <div class="col-sm-9 col-sm-offset-3">
                                                            <input type="hidden" name="id" value="<?php echo $id; ?>">
															<input type="submit" name="editclass" class="btn btn-black" value="Update class">
                                                            
                                                        </div>
                                                    </div>
                                                </div>
											</form>	
                                            </div>
											
                                        </div><!-- /.modal-content -->
                                    </div><!-- /.modal-dialog -->
                                </div><!-- /.modal -->
								<?php } } ?>
								</table>
								</td>  
<?php 
				}
	}
 add_shortcode('popup','popup_function');
 
 
 
 
 
