<?php
/**
* Plugin Name: My Plugin
* Plugin URI: http://mypluginuri.com/
* Description: A brief description about your plugin.
* Version: 1.0 or whatever version of the plugin (pretty self explanatory)
* Author: jasdeep
* Author URI: Author's website
* License: A "Slug" license name e.g. GPL12
*/
session_start();
require(ABSPATH . 'wp-admin/includes/upgrade.php');
//include('wp-config.php');
 
function admin_actions() {
/* add_menu_page('Page Title','Plugin/Menu Title', 'Capability', 'Menu-Slug', 'Function');
    add_submenu_page('Parent-SlugName','Page Title','SubMenu Title','manage_options','SubMenu-Slug','Function');
    add_submenu_page('Parent-SlugName','Page Title','SubMenu Title','manage_options','SubMenu-Slug','Function');
*/
	 add_menu_page( "Yoga style", "Styles",'', "Yoga-style", "" ); 
	 add_submenu_page("Yoga-style", "Yoga style", "List of Yoga Styles", 1, "listyoga-style", "my_function");
	 add_submenu_page("Yoga-style", "Yoga style", "Add Yoga Style", 1, "add-style", "add_style");
	
}
 
add_action('admin_menu', 'admin_actions');

function my_function(){
global $wpdb,$post;
$post_slug=$post->post_name;
if(is_user_logged_in() && !current_user_can( 'administrator' )){
$loginuser_id=get_current_user_id();
}
/* Code for showing usertmeta's yogastyle having yoga style option*/
$str1="select meta_value from wp_usermeta where meta_key='yoga_style' and user_id=".$loginuser_id;
$query1=mysql_query($str1);
	if ($query1){
		$row1=mysql_fetch_assoc($query1);
		//echo "<pre>"; print_r($row1);
		$chek=explode(',',$row1['meta_value']);
	}
/* Code for showing Postmeta's yogastyle having yoga style option*/
$post_authorID = $wpdb->get_col("select post_author from wp_posts where post_author='".$loginuser_id."' and post_type='event'");						
$ID = $wpdb->get_col("select ID from wp_posts where post_author='".$post_authorID[0]."' and post_type='event'");
$postID = $ID[0];
$pmeta="select meta_value from wp_postmeta where meta_key='eyogastyle' and post_id=".$postID;
$psmeta=mysql_query($pmeta);
	if ($psmeta && is_page('edit-event')){
		$pmrow1=mysql_fetch_assoc($psmeta);
		$chek=explode(',',$pmrow1['meta_value']);
	}	
/*End of the code*/
								

if((current_user_can( 'administrator' )) && (empty($post_slug))){  ?>
<script type="text/javascript">
  function del(n){
  document.form1.action="<?php echo site_url();?>/wp-content/plugins/My_plugin/action.php?del_id="+n;
  document.form1.submit();
  }
  function edit(n){
  document.form1.action="<?php echo admin_url();?>/admin.php?page=add-style&edit_id="+n;
  document.form1.submit();
  }
 </script>
  <form name="form1" method="post" action="">
  <table align="center" border="1px">
   <tr>
   <th>S.no.</th>
   <th width="150px">Yoga style name</th>
   <th colspan="2">Action </th>
<?php
}
 $sno=1;								
 $str="select yoga_style_name from `wp_yoga_style` ORDER BY yoga_style_name ASC";
  $rs=mysql_query($str);
  while($row=mysql_fetch_array($rs)){ 
  if((current_user_can( 'administrator' )) && (empty($post_slug)) ){ 
 ?>   
   </tr>
	   <tr>
	   <td width="50px" align="center"><?php echo $sno++; ?></td>
	   <td align="center"><?php echo $row['yoga_style_name']; ?></td>
	   <td width="70px" align="center"><a href="javascript:edit(<?php echo $row['ID'] ?>)">Edit</a></td>
	   <td width="70px" align="center"><a href="javascript:del(<?php echo $row['ID'] ?>)">Delete</a></td>
	   </tr>
	  <?php }

		else if(is_page('teachers')){  ?>                      
			<ul>     
				<li><input type="checkbox" class="chk" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" onchange="getValueUsingClass();" /><?php echo $row['yoga_style_name']; ?></li>
			</ul>
<?php  	}  else if(is_page('school-search')){ ?>
	        <ul>     
				<li><input type="checkbox" class="chk" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" onchange="getValueUsingClass();" /><?php echo $row['yoga_style_name']; ?></li>
			</ul>
     <?php } else if(is_page('search')){ ?>
	 <ul>     
				<li><input type="checkbox" class="chk" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" onchange="getValueUsingClass();" /><?php echo $row['yoga_style_name']; ?></li>
	</ul>
	<?php }else if(is_page('myprofile')){ ?>
			 <div class="col-sm-3 mt20">
				<div class="form-group fs14">
					<input type="checkbox" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" <?php if(in_array($row['yoga_style_name'],$chek)){ ?> checked="checked" <?php } ?> /> <?php echo $row['yoga_style_name']; ?>
				</div>
			</div>
	<?php }else if(is_page('add-event')){ ?>
			 <div class="col-sm-3 mt20">
				<div class="form-group fs14">
					<input type="checkbox" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" /> <?php echo $row['yoga_style_name']; ?>
				</div>
			</div>
	<?php }else if(is_page('add-new-school')){ ?>
			<div class="col-sm-3 mt20">
				<div class="form-group fs14">
					<input type="checkbox" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" /> <?php echo $row['yoga_style_name']; ?>
				</div>
			</div>
	<?php }else if(is_page('add-new-teacher')){ ?>
			<div class="col-sm-3 mt20">
				<div class="form-group fs14">
					<input type="checkbox" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" /> <?php echo $row['yoga_style_name']; ?>
				</div>
			</div>
<?php } else if(is_page('event')){ ?>
	 <ul>     
				<li><input type="checkbox" class="chk" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" onchange="getValueUsingClass();" /><?php echo $row['yoga_style_name']; ?></li>
	</ul>			
	<?php } else if(is_page('class_es')){ ?>                      
			<ul>     
				<li><input type="checkbox" id="chk[]" class="chk" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" onchange="getValueUsingClass();" /><?php echo $row['yoga_style_name']; ?></li>
			</ul>
	<?php } else{ ?>
			<div class="col-sm-3 mt20">
				<div class="form-group fs14">
					<input type="checkbox" name="chk[]" value="<?php echo $row['yoga_style_name']; ?>" <?php if(in_array($row['yoga_style_name'],$chek)){ ?> checked="checked" <?php } ?> /> <?php echo $row['yoga_style_name']; ?>
				</div>
			</div>
<?php
		  }	
    }		  
	 ?>
	</table>
	</form>
	<?php
	
}
 add_shortcode('style','my_function');
 
 function add_style(){
  echo"<h2><center>Add yoga style listing<center></h2> </br>";
 $str="select * from `wp_yoga_style` where ID=".$_REQUEST['edit_id'];
 $rs=mysql_query($str);
 if ($rs){
 $row=mysql_fetch_assoc($rs);
   }
  ?>
  <form name="style" method="post" action="">
  <table align="center" border="0px">
  <tr>
  <th>Yoga style name :- </th>
  <td><input type="text" name="sname" value="<?php echo $row['yoga_style_name']; ?>"></td>
  </tr>
  <tr>
  <?php
  if(isset($_REQUEST['edit_id'])){ ?>
  <td><input type="submit" name="update" value="Update style"><td>
  <?php } else { ?>
  <td><input type="submit" name="sub" value="Add Style"><td>
  <?php } ?>
  </tr>
  </table>
  </form>
  
  <?php
  if(isset($_POST['sub'])){
  // echo"<pre>"; print_r($_POST);
   $name=$_POST['sname'];
   mysql_query("INSERT INTO `wp_yoga_style` VALUES(' ','$name')");
   }
   else if(isset($_POST['update'])){
   $name=$_POST['sname'];
    mysql_query("UPDATE `wp_yoga_style` SET yoga_style_name='$name' WHERE ID=".$_REQUEST['edit_id']);
	wp_redirect(site_url().'/wp-admin/admin.php?page=listyoga-style');
   }
 }
 
